# Solar Ramp Detector — Standalone Vercel Deploy

Three.js particle background · Scroll-driven sections · 3D project grid
Live HuggingFace inference · Supabase logging · Strict B&W design system

---

## Deploy in 5 steps

### 1. Clone and install
```bash
git clone https://github.com/srinath9121/Nath-portfolio.git solar-site
# OR just drag the solar-vercel folder into a new GitHub repo

cd solar-vercel
npm install
```

### 2. Supabase
1. Go to https://supabase.com → your project → SQL Editor
2. Paste and run `supabase-schema.sql`
3. Go to Settings → API → copy the three keys

### 3. Environment variables
```bash
cp .env.example .env.local
# Fill in your Supabase keys
```

### 4. Test locally
```bash
npm run dev
# Open http://localhost:3000
```

### 5. Deploy to Vercel
```bash
# Option A — Vercel CLI
npx vercel

# Option B — Push to GitHub, import at vercel.com
git init
git add .
git commit -m "init"
git remote add origin https://github.com/YOU/solar-site.git
git push -u origin main
# Then: vercel.com → New Project → import repo
```

Add the 3 env vars in Vercel → Project → Settings → Environment Variables.

---

## File structure
```
app/
  layout.tsx          root layout, cursor, grain, scroll bar
  page.tsx            homepage: hero + stats + 3D project grid
  globals.css         design tokens, fonts, animations
  solar/
    layout.tsx        /solar metadata + page transition
    page.tsx          4-section scroll experience + live inference
  api/
    predict/
      route.ts        POST: HuggingFace proxy + Supabase logging
components/
  ParticleCanvas.tsx  Three.js background, scroll+pred reactive
supabase-schema.sql   DB tables + stats view
```

---

## Particle states
| Prediction | Colour | Motion |
|---|---|---|
| No-Ramp (0) | Teal / Blue | Calm drift |
| Moderate (1) | Amber | Turbulent clusters |
| Severe (2) | Red | Vortex spiral + alarm |
