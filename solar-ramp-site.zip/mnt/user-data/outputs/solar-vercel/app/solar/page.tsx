"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import dynamic from "next/dynamic";

const ParticleCanvas = dynamic(() => import("@/components/ParticleCanvas"), { ssr: false });

type Cls = 0 | 1 | 2;
const NAMES  = ["No-Ramp", "Moderate", "Severe"] as const;
const DOTS   = ["○", "◑", "●"] as const;
const UNSEEN = 169_372;

interface Result {
  sample_idx: number;
  verdict:    string;
  pred_class: Cls;
  true_class: Cls;
  correct:    boolean;
  p_noramp:   number;
  p_moderate: number;
  p_severe:   number;
  pred_pv?:   number;
  true_pv?:   number;
  drop_pct?:  number;
  session_id?:string;
  error?:     string;
}

// ─── HOOKS ────────────────────────────────────────────────────
function useScrollY() {
  const [y, setY] = useState(0);
  useEffect(() => {
    const fn = () => setY(window.scrollY);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);
  return y;
}

function useReveal(threshold = 0.12) {
  const ref = useRef<HTMLDivElement>(null);
  const [v, setV] = useState(false);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    const ob = new IntersectionObserver(([e]) => { if (e.isIntersecting) setV(true); }, { threshold });
    ob.observe(el); return () => ob.disconnect();
  }, [threshold]);
  return { ref, v };
}

export default function SolarPage() {
  const scrollY    = useScrollY();
  const [cls, setCls]       = useState<Cls>(0);
  const [sample, setSample] = useState(0);
  const [theta, setTheta]   = useState(0.30);
  const [blind, setBlind]   = useState(false);
  const [loading, setLoad]  = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const [sid, setSid]       = useState<string>();
  const [history, setHist]  = useState<Result[]>([]);
  const [active, setActive] = useState("hero");

  const SECS = ["hero","model","inference","results"];

  useEffect(() => {
    const fn = () => {
      for (const id of [...SECS].reverse()) {
        const el = document.getElementById(id);
        if (el && el.getBoundingClientRect().top <= 110) { setActive(id); break; }
      }
    };
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const predict = useCallback(async (idx?: number) => {
    setLoad(true);
    try {
      const res = await fetch("/api/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sample_idx: idx ?? sample, theta, session_id: sid }),
      });
      const data: Result = await res.json();
      if (!data.error) {
        setResult(data);
        setCls(data.pred_class);
        if (data.session_id) setSid(data.session_id);
        setHist(h => [data, ...h].slice(0, 8));
        if (data.pred_class === 2) alarm();
      }
    } catch {}
    finally { setLoad(false); }
  }, [sample, theta, sid]);

  const jump = (c: Cls) => {
    const idx = Math.floor(Math.random() * UNSEEN);
    setSample(idx); predict(idx);
  };

  const heroR  = useReveal(0.01);
  const modelR = useReveal(0.1);
  const resR   = useReveal(0.1);

  return (
    <main style={{ background: "var(--bg)", minHeight: "100vh", overflowX: "hidden" }}>
      <ParticleCanvas predClass={cls} scrollY={scrollY} />

      {/* ── Side nav ─────────────────────────────────────── */}
      <nav style={{
        position: "fixed", left: "28px", top: "50%",
        transform: "translateY(-50%)",
        zIndex: 100, display: "flex", flexDirection: "column", gap: "18px",
      }}>
        {[["hero","01"],["model","02"],["inference","03"],["results","04"]].map(([id,n]) => (
          <a key={id} href={`#${id}`} style={{
            fontFamily: "var(--font-mono)", fontSize: "0.55rem",
            letterSpacing: "0.18em", textTransform: "uppercase",
            color: active===id ? "var(--white)" : "var(--muted)",
            textDecoration: "none", writingMode: "vertical-rl",
            transform: "rotate(180deg)",
            transition: "color 0.25s",
          }}>{n} — {id}</a>
        ))}
      </nav>

      {/* Back link */}
      <Link href="/" style={{
        position: "fixed", top: "28px", left: "6vw",
        fontFamily: "var(--font-mono)", fontSize: "0.6rem",
        letterSpacing: "0.16em", textTransform: "uppercase",
        color: "var(--muted)", textDecoration: "none",
        zIndex: 100, transition: "color 0.2s",
      }}
      onMouseEnter={e => (e.currentTarget.style.color = "var(--white)")}
      onMouseLeave={e => (e.currentTarget.style.color = "var(--muted)")}
      >← Back</Link>

      {/* ═══ HERO ════════════════════════════════════════════ */}
      <section id="hero" ref={heroR.ref} style={{
        height: "100vh", display: "flex", flexDirection: "column",
        justifyContent: "flex-end", padding: "0 6vw 8vh",
        position: "relative", zIndex: 2,
      }}>
        <div style={{
          fontFamily: "var(--font-mono)", fontSize: "0.6rem",
          letterSpacing: "0.2em", color: "var(--muted)",
          textTransform: "uppercase", marginBottom: "20px",
          opacity: heroR.v ? 1 : 0, transition: "opacity 0.8s 0.3s",
        }}>
          V2 · ResNet-18 + LSTM-64 · SKIPPD · Physics-Constrained MTL
        </div>

        <h1 style={{
          fontFamily: "var(--font-disp)",
          fontSize: "clamp(4.5rem, 12vw, 12rem)",
          fontWeight: 900, lineHeight: 0.88,
          letterSpacing: "-0.02em", textTransform: "uppercase",
          color: "var(--white)",
          opacity: heroR.v ? 1 : 0,
          transform: heroR.v ? "translateY(0)" : "translateY(40px)",
          transition: "opacity 0.9s 0.4s var(--ease-out), transform 0.9s 0.4s var(--ease-out)",
        }}>
          Solar<br />Ramp<br />Detector
        </h1>

        <div style={{
          display: "flex", justifyContent: "space-between",
          alignItems: "flex-end", marginTop: "40px",
          opacity: heroR.v ? 1 : 0, transition: "opacity 0.8s 0.8s",
        }}>
          <p style={{
            fontFamily: "var(--font-mono)", fontSize: "0.72rem",
            color: "var(--sub)", lineHeight: 1.75, maxWidth: "380px",
          }}>
            Detecting severe PV output drops ≥15% in 10 minutes on
            169,372 chronologically unseen sky images from the SKIPPD dataset.
          </p>
          <a href="#inference" style={{
            fontFamily: "var(--font-disp)", fontSize: "0.82rem",
            fontWeight: 600, letterSpacing: "0.18em",
            textTransform: "uppercase", color: "var(--white)",
            textDecoration: "none", border: "1px solid var(--white)",
            padding: "14px 32px", transition: "background 0.15s, color 0.15s",
          }}
          onMouseEnter={e => { e.currentTarget.style.background="var(--white)"; e.currentTarget.style.color="var(--bg)"; }}
          onMouseLeave={e => { e.currentTarget.style.background="transparent"; e.currentTarget.style.color="var(--white)"; }}
          >⚡ Run Prediction ↓</a>
        </div>
      </section>

      {/* ═══ MODEL ═══════════════════════════════════════════ */}
      <section id="model" ref={modelR.ref} style={secStyle}>
        <SecHeader n="02" title="Architecture" vis={modelR.v} />
        <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:"1px", background:"var(--line)", border:"1px solid var(--line)", marginBottom:"40px" }}>
          {[
            ["Input",    "64×64 RGB",      "Sky image + PV sequence"],
            ["Vision",   "ResNet-18",       "ImageNet pretrained"],
            ["Temporal", "LSTM-64",         "10-step PV history"],
            ["Output",   "Dual Head",       "Class + regression"],
          ].map(([l,v,s],i) => (
            <div key={i} style={{
              background:"var(--bg)", padding:"28px 22px",
              opacity: modelR.v ? 1:0,
              transform: modelR.v ? "translateY(0)":"translateY(18px)",
              transition:`opacity .7s ${.1+i*.08}s var(--ease-out), transform .7s ${.1+i*.08}s var(--ease-out)`,
            }}>
              <div style={monoLbl}>{l}</div>
              <div style={{ fontFamily:"var(--font-disp)", fontSize:"clamp(1.3rem,2.5vw,2rem)", fontWeight:700, color:"var(--white)", lineHeight:1 }}>{v}</div>
              <div style={{ fontFamily:"var(--font-mono)", fontSize:"0.62rem", color:"var(--muted)", marginTop:"7px", lineHeight:1.5 }}>{s}</div>
            </div>
          ))}
        </div>

        {/* V1 vs V2 */}
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"1px", background:"var(--line)", border:"1px solid var(--line)" }}>
          {[
            { label:"V1 — Baseline", hi:false, rows:[["Severe Recall","47.7%"],["Accuracy","90.3%"],["R²","0.948"],["Loss","Standard CE"]] },
            { label:"V2 — Improved", hi:true,  rows:[["Severe Recall","80.5%"],["Accuracy","80.4%"],["R²","0.950"],["Loss","Physics WMTL"]] },
          ].map((col,ci) => (
            <div key={ci} style={{ background:"var(--bg)", padding:"32px 28px" }}>
              <div style={{ ...monoLbl, color: col.hi ? "var(--white)":"var(--muted)", marginBottom:"20px" }}>{col.label}</div>
              {col.rows.map(([k,v]) => (
                <div key={k} style={{ display:"flex", justifyContent:"space-between", padding:"9px 0", borderBottom:"1px solid var(--line)" }}>
                  <span style={{ fontFamily:"var(--font-mono)", fontSize:"0.68rem", color:"var(--sub)" }}>{k}</span>
                  <span style={{ fontFamily:"var(--font-disp)", fontSize:"0.9rem", fontWeight:600, color: col.hi ? "var(--white)":"var(--muted)" }}>{v}</span>
                </div>
              ))}
            </div>
          ))}
        </div>
      </section>

      {/* ═══ INFERENCE ═══════════════════════════════════════ */}
      <section id="inference" style={secStyle}>
        <SecHeader n="03" title="Live Inference" vis={true} />
        <div style={{ display:"grid", gridTemplateColumns:"260px 1fr", gap:"1px", background:"var(--line)", border:"1px solid var(--line)" }}>

          {/* Controls */}
          <div style={{ background:"var(--bg)", padding:"28px 22px", display:"flex", flexDirection:"column", gap:"20px" }}>
            <div>
              <div style={monoLbl}>Sample Index</div>
              <input type="range" min={0} max={UNSEEN-1} value={sample}
                onChange={e => setSample(+e.target.value)} />
              <div style={{ fontFamily:"var(--font-mono)", fontSize:"0.7rem", color:"var(--sub)", marginTop:"4px" }}>{sample.toLocaleString()}</div>
            </div>
            <div>
              <div style={monoLbl}>Threshold θ</div>
              <input type="range" min={0.1} max={0.9} step={0.05} value={theta}
                onChange={e => setTheta(+e.target.value)} />
              <div style={{ fontFamily:"var(--font-mono)", fontSize:"0.7rem", color:"var(--sub)", marginTop:"4px" }}>{theta.toFixed(2)}</div>
            </div>
            <label style={{ display:"flex", alignItems:"center", gap:"9px", cursor:"pointer" }}>
              <input type="checkbox" checked={blind} onChange={e => setBlind(e.target.checked)}
                style={{ accentColor:"var(--white)", cursor:"pointer" }} />
              <span style={{ fontFamily:"var(--font-mono)", fontSize:"0.62rem", letterSpacing:"0.1em", textTransform:"uppercase", color:"var(--sub)" }}>Blind Mode</span>
            </label>

            <button onClick={() => predict()} disabled={loading} style={{
              fontFamily:"var(--font-disp)", fontSize:"0.82rem", fontWeight:700,
              letterSpacing:"0.14em", textTransform:"uppercase",
              color:"var(--white)", border:"1px solid var(--white)",
              background:"transparent", padding:"12px 0", cursor: loading?"wait":"pointer",
              opacity: loading ? 0.5 : 1, transition:"background .15s, color .15s",
            }}
            onMouseEnter={e => { if(!loading){e.currentTarget.style.background="var(--white)";e.currentTarget.style.color="var(--bg)";} }}
            onMouseLeave={e => { e.currentTarget.style.background="transparent";e.currentTarget.style.color="var(--white)"; }}
            >{loading ? "Running…" : "⚡ Predict"}</button>

            <div style={{ display:"flex", flexDirection:"column", gap:"5px" }}>
              {([2,1,0] as Cls[]).map(c => (
                <button key={c} onClick={() => jump(c)} style={{
                  fontFamily:"var(--font-mono)", fontSize:"0.62rem",
                  letterSpacing:"0.1em", textTransform:"uppercase",
                  color:"var(--muted)", border:"1px solid var(--line2)",
                  background:"transparent", padding:"7px 12px",
                  cursor:"pointer", textAlign:"left", transition:"color .15s, border-color .15s",
                }}
                onMouseEnter={e => { e.currentTarget.style.color="var(--white)"; e.currentTarget.style.borderColor="var(--white)"; }}
                onMouseLeave={e => { e.currentTarget.style.color="var(--muted)"; e.currentTarget.style.borderColor="var(--line2)"; }}
                >
                  {DOTS[c]} &nbsp; Jump → {NAMES[c]}
                </button>
              ))}
            </div>
          </div>

          {/* Result */}
          <div style={{ background:"var(--bg)", padding:"32px", minHeight:"400px", display:"flex", alignItems: (!result&&!loading)?"center":undefined, justifyContent: (!result&&!loading)?"center":undefined }}>
            {!result && !loading && (
              <div style={{ fontFamily:"var(--font-mono)", fontSize:"0.62rem", letterSpacing:"0.2em", color:"var(--muted)", textTransform:"uppercase" }}>
                Press predict to begin
              </div>
            )}
            {loading && <Dots />}
            {result && !loading && <ResultPanel r={result} blind={blind} />}
          </div>
        </div>

        {/* History */}
        {history.length > 0 && (
          <div style={{ border:"1px solid var(--line)", borderTop:"none", background:"var(--bg)", padding:"16px 22px" }}>
            <div style={{ ...monoLbl, marginBottom:"10px" }}>History</div>
            <div style={{ display:"flex", gap:"6px", flexWrap:"wrap" }}>
              {history.map((h,i) => (
                <div key={i} style={{
                  fontFamily:"var(--font-mono)", fontSize:"0.58rem",
                  letterSpacing:"0.08em", padding:"3px 9px",
                  border:`1px solid ${h.correct?"var(--white)":"var(--muted)"}`,
                  color: h.correct?"var(--white)":"var(--muted)",
                }}>
                  {DOTS[h.pred_class]} #{h.sample_idx.toLocaleString()}
                </div>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* ═══ RESULTS ═════════════════════════════════════════ */}
      <section id="results" ref={resR.ref} style={{ ...secStyle, paddingBottom:"140px" }}>
        <SecHeader n="04" title="Results" vis={resR.v} />
        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:"1px", background:"var(--line)", border:"1px solid var(--line)", marginBottom:"1px" }}>
          {[
            ["Severe Recall","80.5%","vs V1: +32.8pp"],
            ["R² Score",     "0.950","Regression head"],
            ["Severe Events","3,422","2.0% of dataset"],
          ].map(([l,v,d],i) => (
            <div key={i} style={{
              background:"var(--bg)", padding:"36px 28px",
              opacity: resR.v?1:0, transform: resR.v?"translateY(0)":"translateY(18px)",
              transition:`opacity .7s ${.1+i*.08}s var(--ease-out), transform .7s ${.1+i*.08}s var(--ease-out)`,
            }}>
              <div style={monoLbl}>{l}</div>
              <div style={{ fontFamily:"var(--font-disp)", fontSize:"clamp(2rem,3.5vw,3rem)", fontWeight:700, color:"var(--white)", lineHeight:1, marginTop:"8px" }}>{v}</div>
              <div style={{ fontFamily:"var(--font-mono)", fontSize:"0.6rem", color:"var(--muted)", marginTop:"7px" }}>{d}</div>
            </div>
          ))}
        </div>
        {/* Distribution bars */}
        <div style={{ background:"var(--bg)", border:"1px solid var(--line)", padding:"36px 28px" }}>
          <div style={{ ...monoLbl, marginBottom:"24px" }}>Label Distribution — Unseen Set</div>
          {[["No-Ramp",93.3,"158,043"],["Moderate",4.7,"7,907"],["Severe",2.0,"3,422"]].map(([n,p,c]) => (
            <div key={n as string} style={{ display:"grid", gridTemplateColumns:"90px 1fr 72px", alignItems:"center", gap:"14px", marginBottom:"14px" }}>
              <span style={{ fontFamily:"var(--font-mono)", fontSize:"0.62rem", letterSpacing:"0.1em", textTransform:"uppercase", color:"var(--sub)" }}>{n}</span>
              <div style={{ height:"1px", background:"var(--line2)", position:"relative" }}>
                <div style={{ position:"absolute", left:0, top:0, height:"1px", background:"var(--white)", width:`${p as number}%`, transition:"width 1.2s var(--ease-out)" }} />
              </div>
              <span style={{ fontFamily:"var(--font-mono)", fontSize:"0.62rem", color:"var(--muted)", textAlign:"right" }}>{c}</span>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}

// ─── RESULT PANEL ─────────────────────────────────────────────
function ResultPanel({ r, blind }: { r: Result; blind: boolean }) {
  const bars: [string, number][] = [
    ["No-Ramp",  r.p_noramp   * 100],
    ["Moderate", r.p_moderate * 100],
    ["Severe",   r.p_severe   * 100],
  ];
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"22px", width:"100%" }}>
      <div>
        <div style={monoLbl}>Prediction</div>
        <div style={{
          fontFamily:"var(--font-disp)",
          fontSize:"clamp(2.2rem,5vw,4rem)",
          fontWeight:800, textTransform:"uppercase",
          color:"var(--white)", letterSpacing:"-0.01em", lineHeight:1,
        }}>
          {DOTS[r.pred_class]} &nbsp;{NAMES[r.pred_class]}
        </div>
        {!blind && (
          <div style={{ fontFamily:"var(--font-mono)", fontSize:"0.72rem", letterSpacing:"0.1em", color: r.correct?"var(--white)":"var(--sub)", marginTop:"6px" }}>
            {r.correct ? "✓ CORRECT" : `✗ WRONG — TRUE: ${NAMES[r.true_class]}`}
          </div>
        )}
      </div>

      <div>
        <div style={monoLbl}>Class Probabilities</div>
        {bars.map(([name,pct],i) => (
          <div key={name} style={{ display:"grid", gridTemplateColumns:"82px 1fr 44px", alignItems:"center", gap:"12px", marginTop:"10px" }}>
            <span style={{ fontFamily:"var(--font-mono)", fontSize:"0.62rem", letterSpacing:"0.08em", textTransform:"uppercase", color:"var(--sub)" }}>{name}</span>
            <div style={{ height:"1px", background:"var(--line2)", position:"relative" }}>
              <div style={{ position:"absolute", left:0, top:0, height:"1px", background: i===r.pred_class?"var(--white)":"var(--muted)", width:`${pct}%`, transition:"width 0.9s var(--ease-out)" }} />
            </div>
            <span style={{ fontFamily:"var(--font-mono)", fontSize:"0.62rem", color: i===r.pred_class?"var(--white)":"var(--muted)", textAlign:"right" }}>{pct.toFixed(1)}%</span>
          </div>
        ))}
      </div>

      {!blind && (r.pred_pv || r.drop_pct != null) && (
        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:"1px", background:"var(--line)", border:"1px solid var(--line)" }}>
          {[["Pred kW", r.pred_pv?.toFixed(2)??"—"], ["True kW", r.true_pv?.toFixed(2)??"—"], ["Drop %", r.drop_pct!=null?`${r.drop_pct.toFixed(1)}%`:"—"]].map(([l,v]) => (
            <div key={l} style={{ background:"var(--bg)", padding:"14px 16px" }}>
              <div style={monoLbl}>{l}</div>
              <div style={{ fontFamily:"var(--font-disp)", fontSize:"1.1rem", fontWeight:700, color:"var(--white)", marginTop:"4px" }}>{v}</div>
            </div>
          ))}
        </div>
      )}

      {r.pred_class === 2 && (
        <div style={{
          border:"1px solid var(--white)", padding:"12px 18px",
          fontFamily:"var(--font-mono)", fontSize:"0.72rem",
          letterSpacing:"0.14em", color:"var(--white)", textTransform:"uppercase",
          animation:"severeBlink 0.5s ease-in-out 4",
        }}>
          ⚠ &nbsp;Severe Ramp Event — Grid Operator Advisory
        </div>
      )}
    </div>
  );
}

// ─── SECTION HEADER ───────────────────────────────────────────
function SecHeader({ n, title, vis }: { n: string; title: string; vis: boolean }) {
  return (
    <div style={{
      display:"flex", alignItems:"baseline", gap:"20px",
      marginBottom:"48px", paddingBottom:"18px", borderBottom:"1px solid var(--line)",
      opacity: vis?1:0, transform: vis?"translateY(0)":"translateY(18px)",
      transition:"opacity .8s .1s var(--ease-out), transform .8s .1s var(--ease-out)",
    }}>
      <span style={{ fontFamily:"var(--font-mono)", fontSize:"0.58rem", letterSpacing:"0.2em", textTransform:"uppercase", color:"var(--muted)" }}>{n}</span>
      <span style={{ fontFamily:"var(--font-disp)", fontSize:"clamp(2rem,4.5vw,3.5rem)", fontWeight:800, textTransform:"uppercase", color:"var(--white)", letterSpacing:"-0.01em" }}>{title}</span>
    </div>
  );
}

function Dots() {
  const [d,setD] = useState(".");
  useEffect(()=>{const t=setInterval(()=>setD(x=>x.length>=3?".":x+"."),380);return()=>clearInterval(t);},[]);
  return <div style={{ fontFamily:"var(--font-mono)", fontSize:"0.62rem", letterSpacing:"0.2em", textTransform:"uppercase", color:"var(--muted)" }}>Querying model{d}</div>;
}

const secStyle: React.CSSProperties = {
  padding:"100px 6vw 80px 7vw",
  position:"relative", zIndex:2,
  borderTop:"1px solid var(--line)",
};

const monoLbl: React.CSSProperties = {
  fontFamily:"var(--font-mono)", fontSize:"0.58rem",
  letterSpacing:"0.18em", textTransform:"uppercase",
  color:"var(--muted)", marginBottom:"8px",
};

function alarm() {
  try {
    const ctx = new ((window as any).AudioContext || (window as any).webkitAudioContext)();
    const b = (f:number,t:number,d:number) => {
      const o=ctx.createOscillator(),g=ctx.createGain();
      o.connect(g);g.connect(ctx.destination);
      o.type="square";o.frequency.setValueAtTime(f,t);
      g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(0.26,t+.005);
      g.gain.setValueAtTime(0.26,t+d-.02);g.gain.linearRampToValueAtTime(0,t+d);
      o.start(t);o.stop(t+d+.01);
    };
    const n=ctx.currentTime;
    [0,.13,.4,.53,.8,.93].forEach(off=>b(1320,n+off,.10));
  } catch {}
}
