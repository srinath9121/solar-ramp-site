import type { Metadata } from "next";

export const metadata: Metadata = {
  title:       "Solar Ramp Detector — V2 · Live Demo",
  description: "Real-time inference on 169,372 unseen SKIPPD sky images. ResNet-18 + LSTM, 80.5% severe recall.",
};

export default function SolarLayout({ children }: { children: React.ReactNode }) {
  return <div className="page-enter">{children}</div>;
}
